import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
VOICE_DIR = DATA_DIR / "voice"
TTS_DIR = DATA_DIR / "tts"

MEMORY_FILE = DATA_DIR / "memory.json"
VOICE_MODE_FILE = DATA_DIR / "voice_mode.json"

BOT_TOKEN = os.getenv("BOT_TOKEN")
ALLOWED_USER_ID = os.getenv("ALLOWED_USER_ID")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5-mini")
OPENAI_TRANSCRIBE_MODEL = os.getenv("OPENAI_TRANSCRIBE_MODEL", "gpt-4o-mini-transcribe")
OPENAI_TTS_MODEL = os.getenv("OPENAI_TTS_MODEL", "gpt-4o-mini-tts")
OPENAI_TTS_VOICE = os.getenv("OPENAI_TTS_VOICE", "marin")

MAX_HISTORY_MESSAGES = 12
MAX_TEXT_REPLY_CHARS = 4000
MAX_TTS_CHARS = 1200

SYSTEM_PROMPT = """
Ты — умный Telegram-бот Артёма.
Отвечай по-русски, понятно, по делу.
Если вопрос технический — объясняй простыми шагами.
Если можно ответить кратко — отвечай кратко.
Если нужен план или инструкция — структурируй.
Учитывай предыдущие сообщения в переписке.
Не выдумывай факты. Если не уверена — так и скажи.
""".strip()


def validate_config() -> None:
    missing = []

    if not BOT_TOKEN:
        missing.append("BOT_TOKEN")
    if not ALLOWED_USER_ID:
        missing.append("ALLOWED_USER_ID")
    if not OPENAI_API_KEY:
        missing.append("OPENAI_API_KEY")

    if missing:
        raise RuntimeError(f"Missing required env vars: {', '.join(missing)}")


def get_allowed_user_id() -> int:
    return int(ALLOWED_USER_ID)  # validated above
