from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters

from app.config import BOT_TOKEN
from app.handlers.command_handlers import (
    start,
    help_command,
    clear_command,
    voice_on_command,
    voice_off_command,
    ping,
    ip_command,
    search,
    uptime_command,
    disk_command,
    ram_command,
    server_command,
    top_command,
    services_command,
    docker_command,
    nginx_command,
    logs_command,
    net_command,
    whoami_command,
    reboot_command,
    cancel_reboot_command,
)
from app.handlers.chat_handlers import chat_message
from app.handlers.voice_handlers import voice_message


def create_bot_app():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("clear", clear_command))
    app.add_handler(CommandHandler("voice_on", voice_on_command))
    app.add_handler(CommandHandler("voice_off", voice_off_command))

    app.add_handler(CommandHandler("ping", ping))
    app.add_handler(CommandHandler("ip", ip_command))
    app.add_handler(CommandHandler("search", search))
    app.add_handler(CommandHandler("uptime", uptime_command))
    app.add_handler(CommandHandler("disk", disk_command))
    app.add_handler(CommandHandler("ram", ram_command))
    app.add_handler(CommandHandler("server", server_command))
    app.add_handler(CommandHandler("top", top_command))
    app.add_handler(CommandHandler("services", services_command))
    app.add_handler(CommandHandler("docker", docker_command))
    app.add_handler(CommandHandler("nginx", nginx_command))
    app.add_handler(CommandHandler("logs", logs_command))
    app.add_handler(CommandHandler("net", net_command))
    app.add_handler(CommandHandler("whoami", whoami_command))
    app.add_handler(CommandHandler("reboot", reboot_command))
    app.add_handler(CommandHandler("cancel_reboot", cancel_reboot_command))

    app.add_handler(MessageHandler(filters.VOICE, voice_message))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, chat_message))

    return app
